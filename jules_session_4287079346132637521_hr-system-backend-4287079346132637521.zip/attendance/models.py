from django.db import models
from django.conf import settings

class SPT(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='spts')
    target_location = models.ForeignKey('locations.Location', on_delete=models.CASCADE)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"SPT {self.user} -> {self.target_location} ({self.start_date.date()})"

class Attendance(models.Model):
    STATUS_CHOICES = (
        ('HADIR', 'Hadir'),
        ('TELAT', 'Telat'),
        ('TUGAS', 'Tugas Luar / SPT'),
        ('SAKIT', 'Sakit'),
        ('CUTI', 'Cuti'),
        ('IZIN', 'Izin'),
        ('ALPHA', 'Alpha / Tanpa Keterangan'),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='attendances')
    location = models.ForeignKey('locations.Location', on_delete=models.SET_NULL, null=True, blank=True)
    
    check_in = models.DateTimeField(null=True, blank=True)
    check_out = models.DateTimeField(null=True, blank=True)
    
    check_in_photo = models.URLField(max_length=500, blank=True, null=True, help_text="URL Foto Selfie")
    check_out_photo = models.URLField(max_length=500, blank=True, null=True)
    
    check_in_lat = models.FloatField(null=True, blank=True)
    check_in_long = models.FloatField(null=True, blank=True)
    
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='ALPHA')
    is_late = models.BooleanField(default=False)
    
    date = models.DateField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'date')

    def __str__(self):
        return f"{self.user} - {self.date} - {self.status}"

class LocationLog(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='location_logs')
    timestamp = models.DateTimeField(auto_now_add=True)
    latitude = models.FloatField()
    longitude = models.FloatField()
    is_in_area = models.BooleanField(default=False)
    
    def __str__(self):
        return f"Log {self.user} - {self.timestamp}"
