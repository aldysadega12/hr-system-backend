from rest_framework import serializers
from .models import Attendance, SPT, LocationLog

class SPTSerializer(serializers.ModelSerializer):
    class Meta:
        model = SPT
        fields = '__all__'

class AttendanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendance
        fields = '__all__'

class LocationLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = LocationLog
        fields = '__all__'
