from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from django.conf import settings
from django.db.models import Q
from .models import Attendance, SPT, LocationLog
from .serializers import AttendanceSerializer, SPTSerializer, LocationLogSerializer
from locations.models import Location
from math import radians, cos, sin, asin, sqrt

def haversine(lon1, lat1, lon2, lat2):
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1 
    dlat = lat2 - lat1 
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a)) 
    r = 6371 # km
    return c * 6371000 # m

def get_allowed_locations(user, now):
    allowed_locations = []
    
    # A. Lokasi SPT
    active_spt = SPT.objects.filter(user=user, start_date__lte=now, end_date__gte=now, is_active=True).first()
    if active_spt:
        allowed_locations.append(active_spt.target_location)
        
    # B. Lokasi Tugas Utama
    if user.main_location:
        allowed_locations.append(user.main_location)
        
    # C. Kantor Utama & Cabang
    general_offices = Location.objects.filter(location_type__in=['MAIN', 'BRANCH'])
    for loc in general_offices:
        if loc not in allowed_locations:
            allowed_locations.append(loc)
            
    return allowed_locations, active_spt

def check_proximity(lat, long, locations):
    min_distance = float('inf')
    valid_loc = None
    nearest_loc = None

    for loc in locations:
        dist = haversine(long, lat, loc.longitude, loc.latitude)
        if dist <= loc.radius_meter:
            valid_loc = loc
            return valid_loc, dist, loc # Return immediately if found
        if dist < min_distance:
            min_distance = dist
            nearest_loc = loc
            
    return None, min_distance, nearest_loc

class SPTViewSet(viewsets.ModelViewSet):
    queryset = SPT.objects.all()
    serializer_class = SPTSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role in ['EMPLOYEE', 'LOCATION_ADMIN']:
            return SPT.objects.filter(user=user)
        return SPT.objects.all()

class AttendanceViewSet(viewsets.ModelViewSet):
    queryset = Attendance.objects.all()
    serializer_class = AttendanceSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        if self.request.user.role == 'EMPLOYEE':
            return Attendance.objects.filter(user=self.request.user)
        return Attendance.objects.all()

    @action(detail=False, methods=['post'])
    def check_in(self, request):
        user = request.user
        lat = float(request.data.get('latitude', 0))
        long = float(request.data.get('longitude', 0))
        photo = request.data.get('photo_url', '')
        now = timezone.now()
        
        allowed_locs, active_spt = get_allowed_locations(user, now)
        valid_loc, dist, nearest = check_proximity(lat, long, allowed_locs)
        
        if not valid_loc:
            return Response({
                "error": "Lokasi tidak valid. Anda berada di luar radius lokasi yang diizinkan.",
                "nearest_distance": dist,
                "nearest_location": nearest.name if nearest else "Unknown"
            }, status=400)

        # Logic Status
        start_hour = getattr(settings, 'WORK_START_HOUR', 8)
        current_hour = now.hour
        is_late = False
        status_attendance = 'HADIR'

        if active_spt and valid_loc == active_spt.target_location:
            status_attendance = 'TUGAS'
        elif current_hour >= start_hour:
             if current_hour > start_hour or (current_hour == start_hour and now.minute > 0):
                status_attendance = 'TELAT'
                is_late = True

        attendance = Attendance.objects.create(
            user=user,
            location=valid_loc,
            check_in=now,
            check_in_photo=photo,
            check_in_lat=lat,
            check_in_long=long,
            status=status_attendance,
            is_late=is_late
        )
        return Response(AttendanceSerializer(attendance).data)

    @action(detail=False, methods=['post'])
    def update_location(self, request):
        user = request.user
        lat = float(request.data.get('latitude', 0))
        long = float(request.data.get('longitude', 0))
        now = timezone.now()
        
        allowed_locs, _ = get_allowed_locations(user, now)
        valid_loc, _, _ = check_proximity(lat, long, allowed_locs)
        
        is_in_area = (valid_loc is not None)
        
        log = LocationLog.objects.create(
            user=user,
            latitude=lat,
            longitude=long,
            is_in_area=is_in_area
        )
        
        return Response({
            "status": "logged", 
            "is_in_area": is_in_area,
            "location": valid_loc.name if valid_loc else None
        })
