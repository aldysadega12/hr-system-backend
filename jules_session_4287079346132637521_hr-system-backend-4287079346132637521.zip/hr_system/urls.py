from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from users.views import UserViewSet
from locations.views import LocationViewSet
from attendance.views import AttendanceViewSet, SPTViewSet
from payroll.views import SalarySlipViewSet, GolonganViewSet

router = DefaultRouter()
router.register(r'users', UserViewSet)
router.register(r'locations', LocationViewSet)
router.register(r'attendance', AttendanceViewSet)
router.register(r'spt', SPTViewSet)
router.register(r'salary-slips', SalarySlipViewSet)
router.register(r'golongan', GolonganViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
]
