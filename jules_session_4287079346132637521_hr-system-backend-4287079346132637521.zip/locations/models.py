from django.db import models

class Location(models.Model):
    LOCATION_TYPES = (
        ('MAIN', 'Kantor Utama'),
        ('BRANCH', 'Kantor Cabang'),
        ('SITE', 'Tempat Tugas / Site'),
    )

    name = models.CharField(max_length=100)
    address = models.TextField()
    location_type = models.CharField(max_length=10, choices=LOCATION_TYPES)
    latitude = models.FloatField()
    longitude = models.FloatField()
    radius_meter = models.IntegerField(default=50, help_text="Radius toleransi absensi dalam meter")

    def __str__(self):
        return f"{self.name} ({self.get_location_type_display()})"
