from django.apps import AppConfig


class PayrollConfig(AppConfig):
    name = "payroll"
