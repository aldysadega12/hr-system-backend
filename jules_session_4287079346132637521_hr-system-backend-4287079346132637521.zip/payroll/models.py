from django.db import models
from django.conf import settings

class Golongan(models.Model):
    name = models.CharField(max_length=50, unique=True, help_text="Contoh: IA, IIA, Senior Staff")
    base_salary = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    allowance = models.DecimalField(max_digits=12, decimal_places=2, default=0, help_text="Total Tunjangan")

    def __str__(self):
        return f"{self.name} - Rp{self.base_salary:,.0f}"

class SalarySlip(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='salary_slips')
    period_month = models.DateField(help_text="Bulan dan Tahun Gaji")
    
    # Pendapatan
    base_salary = models.DecimalField(max_digits=12, decimal_places=2)
    allowance = models.DecimalField(max_digits=12, decimal_places=2)
    
    # Potongan
    late_count = models.IntegerField(default=0)
    late_deduction = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    alpha_count = models.IntegerField(default=0)
    alpha_deduction = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    total_net_salary = models.DecimalField(max_digits=12, decimal_places=2)
    
    generated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'period_month')

    def __str__(self):
        return f"Slip Gaji {self.user} - {self.period_month.strftime('%B %Y')}"
