from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from django.conf import settings
from .models import SalarySlip, Golongan
from .serializers import SalarySlipSerializer, GolonganSerializer
from attendance.models import Attendance
from users.models import User
import calendar

class GolonganViewSet(viewsets.ModelViewSet):
    queryset = Golongan.objects.all()
    serializer_class = GolonganSerializer

class SalarySlipViewSet(viewsets.ModelViewSet):
    queryset = SalarySlip.objects.all()
    serializer_class = SalarySlipSerializer

    @action(detail=False, methods=['post'])
    def generate(self, request):
        user_id = request.data.get('user_id')
        month = int(request.data.get('month'))
        year = int(request.data.get('year'))

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=404)

        if not user.golongan:
            return Response({"error": "User does not have a Golongan assigned"}, status=400)

        # 1. Hitung Kehadiran
        start_date = timezone.datetime(year, month, 1)
        last_day = calendar.monthrange(year, month)[1]
        end_date = timezone.datetime(year, month, last_day)

        attendances = Attendance.objects.filter(
            user=user, 
            date__range=[start_date, end_date]
        )
        
        # Hitung Late
        late_count = attendances.filter(is_late=True).count()
        
        # Hitung Alpha (Simplified: WORK_DAYS - total hadir/izin)
        # Total hari yang "diakui" (bukan alpha)
        recognized_days = attendances.exclude(status='ALPHA').count()
        
        work_days = getattr(settings, 'WORK_DAYS_PER_MONTH', 22)
        alpha_count = max(0, work_days - recognized_days)

        # 2. Hitung Nominal
        base_salary = user.golongan.base_salary
        allowance = user.golongan.allowance
        
        late_deduction_rate = getattr(settings, 'LATE_FINE_AMOUNT', 10000)
        alpha_deduction_rate = base_salary / work_days

        total_late_deduction = late_count * late_deduction_rate
        total_alpha_deduction = alpha_count * alpha_deduction_rate

        total_deduction = total_late_deduction + total_alpha_deduction
        
        gross_salary = base_salary + allowance
        net_salary = gross_salary - total_deduction

        # 3. Simpan / Update Slip
        period_date = start_date.date()
        
        slip, created = SalarySlip.objects.update_or_create(
            user=user,
            period_month=period_date,
            defaults={
                'base_salary': base_salary,
                'allowance': allowance,
                'late_count': late_count,
                'late_deduction': total_late_deduction,
                'alpha_count': alpha_count,
                'alpha_deduction': total_alpha_deduction,
                'total_net_salary': net_salary
            }
        )

        return Response(SalarySlipSerializer(slip).data)
