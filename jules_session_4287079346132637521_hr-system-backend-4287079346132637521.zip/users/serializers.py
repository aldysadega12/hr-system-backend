from rest_framework import serializers
from .models import User
from locations.serializers import LocationSerializer

class UserSerializer(serializers.ModelSerializer):
    location_details = LocationSerializer(source='main_location', read_only=True)

    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'role', 'nip', 'main_location', 'location_details', 'golongan', 'phone_number')
